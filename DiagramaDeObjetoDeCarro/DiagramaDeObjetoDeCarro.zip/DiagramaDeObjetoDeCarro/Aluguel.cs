﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiagramaDeObjetoDeCarro
{
    class Aluguel
    {
        public DateTime DataDeNascimento { get; set; }
        public DateTime DataDevoluçao { get; set; }
    }
}
