﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiagramaDeObjetoDeCarro
{
    class Pagamento
    {
        public String tipo { get; set; }
        public Double valor { get; set; }
    }
}
