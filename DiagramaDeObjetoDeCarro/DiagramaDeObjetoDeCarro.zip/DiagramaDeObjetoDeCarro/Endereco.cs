﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiagramaDeObjetoDeCarro
{
    class Endereco
    {
        public String endereco { get; set; }

        public String bairro { get; set; }
    }
}
