﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiagramaDeObjetoDeCarro
{
    class Reserva
    {
        public DateTime nome { get; set; }
        public String codgio { get; set; }
    }
}
